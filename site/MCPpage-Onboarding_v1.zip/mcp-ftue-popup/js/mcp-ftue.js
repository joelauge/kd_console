/* ===========================================================
   KnowDrive MCP page — first-time-user popup
   Shows once per user (localStorage). Include after the
   #kdFtue markup.
=========================================================== */
(function () {
  var KEY = 'kdMcpFtueDismissed';
  var overlay = document.getElementById('kdFtue');
  if (!overlay) return;

  var modal = document.getElementById('kdFtueModal');

  function open() { overlay.hidden = false; }
  function close() { overlay.hidden = true; }

  // Show on first visit only
  if (!localStorage.getItem(KEY)) open();

  // Close: X button, backdrop, Esc. If the "Don't show next time" checkbox
  // is ticked, the opt-out is permanent; otherwise marked seen for this user.
  var neverBox = document.getElementById('kdFtueNever');
  function dismiss() {
    localStorage.setItem(KEY, neverBox.checked ? 'forever' : 'seen');
    close();
  }
  document.getElementById('kdFtueX').addEventListener('click', dismiss);
  overlay.addEventListener('click', function (e) { if (e.target === overlay) dismiss(); });
  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape' && !overlay.hidden) dismiss();
  });

  // CTA: mark seen, close, and hand focus to the page's setup guides.
  // On the real MCP page, set data-ftue-target on the element to scroll to,
  // or change the selector below.
  document.getElementById('kdFtueCta').addEventListener('click', function () {
    dismiss();
    var target = document.querySelector('[data-ftue-target]');
    if (target) target.scrollIntoView !== undefined && window.scrollTo({ top: target.getBoundingClientRect().top + window.pageYOffset - 20, behavior: 'smooth' });
  });

  // Permanent opt-out is handled by the checkbox state at dismiss time.

  // "Still not clear?" scrolls the modal to the longer explanation
  document.getElementById('kdFtueCue').addEventListener('click', function () {
    modal.scrollTo({ top: modal.scrollHeight, behavior: 'smooth' });
  });

  // Demo-only replay button (not part of the production popup)
  var replay = document.getElementById('ftueReplay');
  if (replay) replay.addEventListener('click', function () {
    localStorage.removeItem(KEY);
    open();
  });
})();
